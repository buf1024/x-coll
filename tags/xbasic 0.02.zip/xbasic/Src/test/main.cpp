/*
 * File       : main.cpp
 * Description: 
 * Version    : 2011-9-26 Created
 * Author     : buf1024@gmail.com
 */


#include "TestCmmHdr.h"

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}


