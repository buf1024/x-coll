/*
 * jmm_log.h
 *
 *  Created on: 2012-6-11
 *      Author: buf1024@gmail.com
 */

#ifndef __48SLOTS_JMM_LOG_H__
#define __48SLOTS_JMM_LOG_H__

#include "clog.h"

int jmm_init_log();
int jmm_uninit_log();

int jmm_init_log_wf();
int jmm_uninit_log_wf();

#endif /* __48SLOTS_JMM_LOG_H__ */
